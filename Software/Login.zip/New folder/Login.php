<?php
session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login</title>

<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/Login.css" rel="stylesheet" type="text/css">

</head>
<body>
 
    

<div class="container-fluid form">
<div class="row">
	<div class="col-sm-6 col-lg-6">
	<form action="LoginConnection.php" method="POST" class="login">
		<h1>Login</h1>
		<p2>Username <br></p2>
		<input type="text" name="user" ><br><br><br>
		<p2>Password<br></p2>
		<input type="password" name="pass" ><br><br><br>
		<input class="button" type="submit" value="Login" name="submit">
		<a href="form.php">Form<br></a>
		<a href="AdminLogin.php">Admin Login<br></a>

	</form>
	</div>
	
</div>
	</div>


<!-- jQuery (necessary for Bootstrap's JavaScript plugins) --> 
<script src="js/jquery-1.11.3.min.js"></script>

<!-- Include all compiled plugins (below), or include individual files as needed --> 
<script src="js/bootstrap.js"></script>
</body>
</html>
